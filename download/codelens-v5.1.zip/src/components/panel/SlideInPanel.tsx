'use client'

import { useMemo } from 'react'
import {
  X,
  ChevronRight,
  MapPin,
  Tag,
  Shield,
  Code2,
  Zap,
  AlertTriangle,
  Bug,
  FlaskConical,
  FileText,
  Route,
  Braces,
  Import,
  Palette,
  Film,
  ExternalLink,
  Lock,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import type {
  GraphNode,
  NodeDetail,
  QuickAction,
  NodeType,
  NodeStatus,
} from '@/types/neural'
import { NEURAL_COLORS, getNodeShape } from '@/types/neural'

// ─── Props ───────────────────────────────────────────────────
interface SlideInPanelProps {
  theme: 'dark' | 'light'
  node: GraphNode | null
  detail: NodeDetail | null
  quickActions: QuickAction[]
  onAction: (action: QuickAction) => void
  onClose: () => void
}

// ─── Helpers ─────────────────────────────────────────────────
const SHAPE_ICONS: Record<string, string> = {
  circle: '●',
  hexagon: '⬡',
  diamond: '◆',
  triangle: '▲',
  star: '★',
  square: '■',
  ring: '◎',
}

const TYPE_LABELS: Record<NodeType, string> = {
  class: 'CSS Class',
  id: 'HTML ID',
  function: 'Function',
  component: 'Component',
  store: 'Store',
  file: 'File',
  package: 'Package',
  route: 'Route',
  env_var: 'Env Variable',
  variable: 'Variable',
  secret: 'Secret',
  vulnerability: 'Vulnerability',
  test: 'Test',
  import: 'Import',
  css_var: 'CSS Variable',
  keyframe: 'Keyframe',
}

const STATUS_COLORS: Record<NodeStatus, string> = {
  active: NEURAL_COLORS.active,
  dead: NEURAL_COLORS.dead,
  vulnerable: NEURAL_COLORS.vulnerable,
  critical: NEURAL_COLORS.critical,
  safe: NEURAL_COLORS.safe,
  orphan: NEURAL_COLORS.orphan,
  warning: NEURAL_COLORS.warning,
  duplicate_define: NEURAL_COLORS.warning,
  collision: NEURAL_COLORS.vulnerable,
  impure: NEURAL_COLORS.warning,
  untested: NEURAL_COLORS.untested,
  unused: NEURAL_COLORS.unused,
}

function shapeIcon(type: NodeType): string {
  const shape = getNodeShape(type)
  return SHAPE_ICONS[shape] ?? '●'
}

// ─── Sub-components ──────────────────────────────────────────

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <div className="mb-2">
      <h4
        className="text-[10px] font-bold uppercase tracking-[0.1em] flex items-center gap-1.5"
        style={{ color: 'rgba(139, 92, 246, 0.5)' }}
      >
        {children}
      </h4>
      {/* Gradient underline */}
      <div
        className="h-px mt-1"
        style={{
          background: 'linear-gradient(90deg, rgba(139, 92, 246, 0.2), rgba(139, 92, 246, 0.05), transparent)',
        }}
      />
    </div>
  )
}

function ProgressBar({ value, color, label }: { value: number; color: string; label: string }) {
  const pct = Math.min(100, Math.max(0, value * 100))
  return (
    <div className="space-y-1.5">
      <div className="flex justify-between text-xs">
        <span className="opacity-60">{label}</span>
        <span className="font-mono text-[10px] opacity-50">{Math.round(pct)}%</span>
      </div>
      <div className="h-1 rounded-full overflow-hidden" style={{ backgroundColor: 'rgba(139, 92, 246, 0.08)' }}>
        <div
          className="h-full rounded-full transition-all duration-700 ease-out"
          style={{
            width: `${pct}%`,
            backgroundColor: color,
            boxShadow: `0 0 8px ${color}40`,
          }}
        />
      </div>
    </div>
  )
}

function RefList({
  items,
  dark,
}: {
  items: Array<{ fn?: string; file: string; line: number; source?: string }>
  dark: boolean
}) {
  return (
    <ul className="space-y-1">
      {items.map((item, i) => (
        <li
          key={`${item.file}:${item.line}:${i}`}
          className="flex items-center gap-1.5 text-xs py-0.5 px-1.5 rounded-md transition-colors duration-150 hover:bg-white/[0.03]"
        >
          <ChevronRight className="h-3 w-3 shrink-0 opacity-30" />
          <span className="font-medium truncate">{item.fn ?? item.source ?? 'ref'}</span>
          <span
            className={`ml-auto shrink-0 font-mono text-[10px] ${dark ? 'text-slate-500' : 'text-slate-400'}`}
          >
            {item.file}:{item.line}
          </span>
        </li>
      ))}
    </ul>
  )
}

// ─── Type-specific sections ──────────────────────────────────

function FunctionSection({ detail, dark }: { detail: NodeDetail; dark: boolean }) {
  return (
    <>
      {(detail.callers && detail.callers.length > 0) && (
        <div className="space-y-1 fade-in">
          <SectionTitle>Callers</SectionTitle>
          <RefList items={detail.callers!.map(c => ({ fn: c.fn, file: c.file, line: c.line }))} dark={dark} />
        </div>
      )}
      {(detail.callees && detail.callees.length > 0) && (
        <div className="space-y-1 fade-in">
          <SectionTitle>Callees</SectionTitle>
          <RefList items={detail.callees!.map(c => ({ fn: c.fn, file: c.file, line: c.line }))} dark={dark} />
        </div>
      )}

      <div className="divider-glow" />

      <div className="fade-in">
        <SectionTitle>Analysis</SectionTitle>
        <div className="space-y-3">
          {detail.purity !== undefined && (
            <ProgressBar
              value={detail.purity}
              color={detail.purity > 0.7 ? '#10b981' : detail.purity > 0.4 ? '#f59e0b' : '#ef4444'}
              label="Purity"
            />
          )}
          {detail.complexity !== undefined && (
            <ProgressBar
              value={1 - Math.min(detail.complexity / 20, 1)}
              color={detail.complexity > 15 ? '#ef4444' : detail.complexity > 8 ? '#f59e0b' : '#10b981'}
              label={`Complexity (${detail.complexity})`}
            />
          )}
          {detail.coverage !== undefined && (
            <div className="flex items-center gap-2 text-xs">
              <span className="opacity-60">Test coverage:</span>
              {detail.coverage ? (
                <Badge variant="outline" className="text-[10px] h-5 border-emerald-500/40 text-emerald-400 bg-emerald-500/5">
                  Covered
                </Badge>
              ) : (
                <Badge variant="outline" className="text-[10px] h-5 border-red-400/40 text-red-400 bg-red-500/5">
                  Uncovered
                </Badge>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  )
}

function CssClassSection({ detail, dark }: { detail: NodeDetail; dark: boolean }) {
  return (
    <>
      {detail.definedIn && detail.definedIn.length > 0 && (
        <div className="space-y-1 fade-in">
          <SectionTitle>Defined In</SectionTitle>
          <RefList items={detail.definedIn!.map(d => ({ file: d.file, line: d.line, source: 'CSS' }))} dark={dark} />
        </div>
      )}
      {detail.references && detail.references.length > 0 && (
        <div className="space-y-1 fade-in">
          <SectionTitle>Used By</SectionTitle>
          <RefList items={detail.references!.map(r => ({ file: r.file, line: r.line, source: r.source }))} dark={dark} />
        </div>
      )}
      {detail.issues && detail.issues.length > 0 && (
        <>
          <div className="divider-glow" />
          <div className="space-y-1.5 fade-in">
            <SectionTitle>Issues</SectionTitle>
            {detail.issues!.map((issue, i) => (
              <div
                key={`issue-${i}`}
                className={`text-xs px-2.5 py-2 rounded-lg border transition-colors ${
                  issue.severity === 'error'
                    ? 'bg-red-500/5 border-red-500/10 text-red-400'
                    : issue.severity === 'warning'
                      ? 'bg-amber-500/5 border-amber-500/10 text-amber-400'
                      : 'bg-slate-500/5 border-slate-500/10 text-slate-400'
                }`}
              >
                <span className="font-medium">{issue.category}</span>
                <span className="mx-1 opacity-30">·</span>
                <span className="opacity-70">{issue.message}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </>
  )
}

function IdSection({ detail, node, dark }: { detail: NodeDetail; node: GraphNode; dark: boolean }) {
  const hasCollision = node.status === 'collision'
  return (
    <>
      {detail.definedIn && detail.definedIn.length > 0 && (
        <div className="space-y-1 fade-in">
          <SectionTitle>HTML Definition</SectionTitle>
          <RefList items={detail.definedIn!.map(d => ({ file: d.file, line: d.line, source: 'HTML' }))} dark={dark} />
        </div>
      )}
      {detail.references && detail.references.length > 0 && (
        <div className="space-y-1 fade-in">
          <SectionTitle>Accessed By</SectionTitle>
          <RefList items={detail.references!.map(r => ({ file: r.file, line: r.line, source: r.source }))} dark={dark} />
        </div>
      )}
      <div className="divider-glow" />
      <div className="space-y-1 fade-in">
        <SectionTitle>Collision</SectionTitle>
        {hasCollision ? (
          <Badge variant="outline" className="text-[10px] h-5 border-red-400/40 text-red-400 bg-red-500/5">
            ⚠ Collision detected
          </Badge>
        ) : (
          <Badge variant="outline" className="text-[10px] h-5 border-emerald-500/40 text-emerald-400 bg-emerald-500/5">
            ✓ No collision
          </Badge>
        )}
      </div>
    </>
  )
}

function ComponentSection({ detail, node, dark }: { detail: NodeDetail; node: GraphNode; dark: boolean }) {
  const data = node.data as Record<string, unknown>
  const props = data?.props as string[] | undefined
  const renderTree = data?.renderTree as string[] | undefined
  const connectedStores = data?.connectedStores as string[] | undefined

  return (
    <>
      {props && props.length > 0 && (
        <div className="space-y-1.5 fade-in">
          <SectionTitle>Props</SectionTitle>
          <div className="flex flex-wrap gap-1">
            {props.map(p => (
              <Badge key={p} variant="secondary" className="text-[10px] h-5 bg-purple-500/5 text-purple-300 border-purple-500/10">
                {p}
              </Badge>
            ))}
          </div>
        </div>
      )}
      {renderTree && renderTree.length > 0 && (
        <div className="space-y-1 fade-in">
          <SectionTitle>Render Tree</SectionTitle>
          <ul className="space-y-0.5">
            {renderTree.map((child, i) => (
              <li key={`rt-${i}`} className="flex items-center gap-1.5 text-xs py-0.5">
                <ChevronRight className="h-3 w-3 opacity-30" />
                <span>{child}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      {connectedStores && connectedStores.length > 0 && (
        <div className="space-y-1.5 fade-in">
          <SectionTitle>Connected Stores</SectionTitle>
          <div className="flex flex-wrap gap-1">
            {connectedStores.map(s => (
              <Badge key={s} variant="outline" className="text-[10px] h-5 border-amber-400/30 text-amber-400 bg-amber-500/5">
                {s}
              </Badge>
            ))}
          </div>
        </div>
      )}
    </>
  )
}

function StoreSection({ detail, node, dark }: { detail: NodeDetail; node: GraphNode; dark: boolean }) {
  const data = node.data as Record<string, unknown>
  const reads = data?.reads as string[] | undefined
  const writes = data?.writes as string[] | undefined
  const flow = data?.flow as string[] | undefined

  return (
    <>
      {reads && reads.length > 0 && (
        <div className="space-y-1.5 fade-in">
          <SectionTitle>Reads</SectionTitle>
          <div className="flex flex-wrap gap-1">
            {reads.map(r => (
              <Badge key={r} variant="secondary" className="text-[10px] h-5 bg-blue-500/5 text-blue-300 border-blue-500/10">
                {r}
              </Badge>
            ))}
          </div>
        </div>
      )}
      {writes && writes.length > 0 && (
        <div className="space-y-1.5 fade-in">
          <SectionTitle>Writes</SectionTitle>
          <div className="flex flex-wrap gap-1">
            {writes.map(w => (
              <Badge key={w} variant="outline" className="text-[10px] h-5 border-amber-400/30 text-amber-400 bg-amber-500/5">
                {w}
              </Badge>
            ))}
          </div>
        </div>
      )}
      {flow && flow.length > 0 && (
        <>
          <div className="divider-glow" />
          <div className="space-y-1 fade-in">
            <SectionTitle>State Change Flow</SectionTitle>
            <ul className="space-y-0.5">
              {flow.map((step, i) => (
                <li key={`flow-${i}`} className="flex items-center gap-1.5 text-xs py-0.5">
                  <span className="opacity-30 text-[10px] font-mono w-4 text-right">{i + 1}.</span>
                  <span>{step}</span>
                </li>
              ))}
            </ul>
          </div>
        </>
      )}
    </>
  )
}

function PackageSection({ detail, node, dark }: { detail: NodeDetail; node: GraphNode; dark: boolean }) {
  const data = node.data as Record<string, unknown>
  const version = data?.version as string | undefined
  const vulnerabilities = data?.vulnerabilities as Array<{ cve: string; severity: string; url?: string }> | undefined
  const dependents = data?.dependents as string[] | undefined

  return (
    <>
      {version && (
        <div className="space-y-1 fade-in">
          <SectionTitle>Version</SectionTitle>
          <span className="text-sm font-mono px-2 py-0.5 rounded-md" style={{ backgroundColor: dark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.04)' }}>
            {version}
          </span>
        </div>
      )}
      {vulnerabilities && vulnerabilities.length > 0 && (
        <div className="space-y-1.5 fade-in">
          <SectionTitle>Vulnerabilities</SectionTitle>
          {vulnerabilities.map((v, i) => (
            <div
              key={`vuln-${i}`}
              className={`text-xs px-2.5 py-2 rounded-lg border ${
                v.severity === 'critical'
                  ? 'bg-red-500/5 border-red-500/10 text-red-400'
                  : v.severity === 'high'
                    ? 'bg-orange-500/5 border-orange-500/10 text-orange-400'
                    : 'bg-amber-500/5 border-amber-500/10 text-amber-400'
              }`}
            >
              <span className="font-mono font-medium">{v.cve}</span>
              <span className="mx-1 opacity-30">·</span>
              <span className="opacity-70">{v.severity}</span>
            </div>
          ))}
        </div>
      )}
      {(!vulnerabilities || vulnerabilities.length === 0) && (
        <div className="space-y-1 fade-in">
          <SectionTitle>Vulnerabilities</SectionTitle>
          <Badge variant="outline" className="text-[10px] h-5 border-emerald-500/40 text-emerald-400 bg-emerald-500/5">
            ✓ No known CVEs
          </Badge>
        </div>
      )}
      {dependents && dependents.length > 0 && (
        <>
          <div className="divider-glow" />
          <div className="space-y-1.5 fade-in">
            <SectionTitle>Dependents</SectionTitle>
            <div className="flex flex-wrap gap-1">
              {dependents.map(d => (
                <Badge key={d} variant="secondary" className="text-[10px] h-5 bg-slate-500/5">
                  {d}
                </Badge>
              ))}
            </div>
          </div>
        </>
      )}
    </>
  )
}

function EnvVarSection({ detail, node, dark }: { detail: NodeDetail; node: GraphNode; dark: boolean }) {
  const data = node.data as Record<string, unknown>
  const required = data?.required as boolean | undefined
  const hasFallback = data?.hasFallback as boolean | undefined
  const documented = data?.documented as boolean | undefined
  const files = data?.files as string[] | undefined

  return (
    <>
      <div className="space-y-2 fade-in">
        <SectionTitle>Properties</SectionTitle>
        <div className="grid grid-cols-3 gap-2 text-xs">
          <div className="space-y-1 text-center">
            <span className="opacity-50 text-[10px]">Required</span>
            <div>
              {required ? (
                <Badge variant="outline" className="text-[10px] h-5 border-red-400/40 text-red-400 bg-red-500/5">Yes</Badge>
              ) : (
                <Badge variant="outline" className="text-[10px] h-5 border-emerald-500/40 text-emerald-400 bg-emerald-500/5">No</Badge>
              )}
            </div>
          </div>
          <div className="space-y-1 text-center">
            <span className="opacity-50 text-[10px]">Fallback</span>
            <div>
              {hasFallback ? (
                <Badge variant="outline" className="text-[10px] h-5 border-emerald-500/40 text-emerald-400 bg-emerald-500/5">Yes</Badge>
              ) : (
                <Badge variant="outline" className="text-[10px] h-5 border-amber-400/40 text-amber-400 bg-amber-500/5">None</Badge>
              )}
            </div>
          </div>
          <div className="space-y-1 text-center">
            <span className="opacity-50 text-[10px]">Documented</span>
            <div>
              {documented ? (
                <Badge variant="outline" className="text-[10px] h-5 border-emerald-500/40 text-emerald-400 bg-emerald-500/5">Yes</Badge>
              ) : (
                <Badge variant="outline" className="text-[10px] h-5 border-slate-400/40 text-slate-400 bg-slate-500/5">No</Badge>
              )}
            </div>
          </div>
        </div>
      </div>
      {files && files.length > 0 && (
        <>
          <div className="divider-glow" />
          <div className="space-y-1 fade-in">
            <SectionTitle>Files</SectionTitle>
            <ul className="space-y-0.5">
              {files.map((f, i) => (
                <li key={`file-${i}`} className="flex items-center gap-1.5 text-xs font-mono py-0.5">
                  <ChevronRight className="h-3 w-3 opacity-30" />
                  <span className="opacity-80">{f}</span>
                </li>
              ))}
            </ul>
          </div>
        </>
      )}
    </>
  )
}

function SecretSection({ detail, node, dark }: { detail: NodeDetail; node: GraphNode; dark: boolean }) {
  const data = node.data as Record<string, unknown>
  const severity = data?.severity as string | undefined
  const category = data?.category as string | undefined
  const matchPattern = data?.matchPattern as string | undefined

  const severityColor =
    severity === 'critical'
      ? 'border-red-500/40 text-red-400 bg-red-500/5'
      : severity === 'high'
        ? 'border-orange-500/40 text-orange-400 bg-orange-500/5'
        : 'border-amber-500/40 text-amber-400 bg-amber-500/5'

  return (
    <>
      <div className="space-y-2 fade-in">
        <SectionTitle>
          <Lock className="h-3 w-3 inline mr-1" />
          Secret Details
        </SectionTitle>
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-xs">
            <span className="opacity-50">Severity:</span>
            <Badge variant="outline" className={`text-[10px] h-5 ${severityColor}`}>
              {severity ?? 'unknown'}
            </Badge>
          </div>
          {category && (
            <div className="flex items-center gap-2 text-xs">
              <span className="opacity-50">Category:</span>
              <span className="opacity-80">{category}</span>
            </div>
          )}
        </div>
      </div>
      {matchPattern && (
        <div className="space-y-1 fade-in">
          <SectionTitle>Match Pattern</SectionTitle>
          <div
            className="rounded-lg px-3 py-2 text-xs font-mono"
            style={{ backgroundColor: dark ? 'rgba(0,0,0,0.25)' : 'rgba(0,0,0,0.03)' }}
          >
            {matchPattern.replace(/./g, (ch, i) => (i > 3 ? '•' : ch))}
          </div>
        </div>
      )}
      <div className="divider-glow" />
      <div className="space-y-1.5 fade-in">
        <SectionTitle>
          <AlertTriangle className="h-3 w-3 inline mr-1" />
          Remediation
        </SectionTitle>
        <div
          className="text-xs px-2.5 py-2 rounded-lg border bg-amber-500/5 border-amber-500/10 text-amber-400"
        >
          <span className="font-medium">Move to environment variable</span>
          <span className="mx-1 opacity-30">·</span>
          <span className="opacity-70">Store this secret as an env var and reference it via process.env</span>
        </div>
      </div>
      {node.file && (
        <>
          <div className="divider-glow" />
          <div className="space-y-1 fade-in">
            <SectionTitle>Quick Context</SectionTitle>
            <div className="flex items-center gap-1.5 text-xs">
              <ChevronRight className="h-3 w-3 opacity-30" />
              <span className="font-mono opacity-70">{node.file}{node.line ? `:${node.line}` : ''}</span>
            </div>
          </div>
        </>
      )}
    </>
  )
}

function VulnerabilitySection({ detail, node, dark }: { detail: NodeDetail; node: GraphNode; dark: boolean }) {
  const data = node.data as Record<string, unknown>
  const cveId = data?.cveId as string | undefined
  const packageName = data?.packageName as string | undefined
  const installedVersion = data?.installedVersion as string | undefined
  const severity = data?.severity as string | undefined
  const description = data?.description as string | undefined

  const severityColor =
    severity === 'critical'
      ? 'border-red-500/40 text-red-400 bg-red-500/5'
      : severity === 'high'
        ? 'border-orange-500/40 text-orange-400 bg-orange-500/5'
        : severity === 'medium'
          ? 'border-amber-500/40 text-amber-400 bg-amber-500/5'
          : 'border-slate-500/40 text-slate-400 bg-slate-500/5'

  return (
    <>
      <div className="space-y-2 fade-in">
        <SectionTitle>
          <Bug className="h-3 w-3 inline mr-1" />
          Vulnerability Details
        </SectionTitle>
        <div className="space-y-1.5">
          {cveId && (
            <div className="flex items-center gap-2 text-xs">
              <span className="opacity-50">CVE:</span>
              <span className="font-mono font-medium">{cveId}</span>
            </div>
          )}
          {packageName && (
            <div className="flex items-center gap-2 text-xs">
              <span className="opacity-50">Package:</span>
              <span className="opacity-80">{packageName}</span>
            </div>
          )}
          {installedVersion && (
            <div className="flex items-center gap-2 text-xs">
              <span className="opacity-50">Installed:</span>
              <span className="font-mono px-2 py-0.5 rounded-md" style={{ backgroundColor: dark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.04)' }}>
                {installedVersion}
              </span>
            </div>
          )}
          <div className="flex items-center gap-2 text-xs">
            <span className="opacity-50">Severity:</span>
            <Badge variant="outline" className={`text-[10px] h-5 ${severityColor}`}>
              {severity ?? 'unknown'}
            </Badge>
          </div>
        </div>
      </div>
      {description && (
        <div className="space-y-1 fade-in">
          <SectionTitle>Description</SectionTitle>
          <p className="text-xs opacity-70 leading-relaxed">{description}</p>
        </div>
      )}
      <div className="divider-glow" />
      <div className="space-y-1.5 fade-in">
        <SectionTitle>
          <Shield className="h-3 w-3 inline mr-1" />
          Fix
        </SectionTitle>
        <div
          className="text-xs px-2.5 py-2 rounded-lg border bg-emerald-500/5 border-emerald-500/10 text-emerald-400"
        >
          <span className="font-medium">Update to latest version</span>
          <span className="mx-1 opacity-30">·</span>
          <span className="opacity-70">Run package update to resolve this CVE</span>
        </div>
      </div>
    </>
  )
}

function TestSection({ detail, node, dark }: { detail: NodeDetail; node: GraphNode; dark: boolean }) {
  const data = node.data as Record<string, unknown>
  const testedSymbol = data?.testedSymbol as string | undefined
  const framework = data?.framework as string | undefined
  const testFile = data?.testFile as string | undefined

  return (
    <>
      <div className="space-y-2 fade-in">
        <SectionTitle>
          <FlaskConical className="h-3 w-3 inline mr-1" />
          Test Details
        </SectionTitle>
        <div className="space-y-1.5">
          {testFile && (
            <div className="flex items-center gap-2 text-xs">
              <span className="opacity-50">File:</span>
              <span className="font-mono opacity-80">{testFile}</span>
            </div>
          )}
          {testedSymbol && (
            <div className="flex items-center gap-2 text-xs">
              <span className="opacity-50">Tested symbol:</span>
              <Badge variant="secondary" className="text-[10px] h-5 bg-purple-500/5 text-purple-300 border-purple-500/10">
                {testedSymbol}
              </Badge>
            </div>
          )}
          {framework && (
            <div className="flex items-center gap-2 text-xs">
              <span className="opacity-50">Framework:</span>
              <Badge variant="outline" className="text-[10px] h-5 border-slate-400/30 text-slate-400 bg-slate-500/5">
                {framework}
              </Badge>
            </div>
          )}
        </div>
      </div>
      {detail.tests && detail.tests.length > 0 && (
        <>
          <div className="divider-glow" />
          <div className="space-y-1 fade-in">
            <SectionTitle>Test References</SectionTitle>
            <RefList items={detail.tests!.map(t => ({ file: t.file, line: t.line, fn: testedSymbol }))} dark={dark} />
          </div>
        </>
      )}
      {testedSymbol && (
        <>
          <div className="divider-glow" />
          <div className="space-y-1.5 fade-in">
            <SectionTitle>
              <ExternalLink className="h-3 w-3 inline mr-1" />
              Tested Function
            </SectionTitle>
            <div className="flex items-center gap-1.5 text-xs py-0.5 px-1.5 rounded-md transition-colors duration-150 hover:bg-white/[0.03]">
              <ChevronRight className="h-3 w-3 shrink-0 opacity-30" />
              <span className="font-medium">{testedSymbol}</span>
            </div>
          </div>
        </>
      )}
    </>
  )
}

function FileSection({ detail, node, dark }: { detail: NodeDetail; node: GraphNode; dark: boolean }) {
  const data = node.data as Record<string, unknown>
  const symbolsCount = data?.symbolsCount as number | undefined
  const importsCount = data?.importsCount as number | undefined
  const owner = data?.owner as string | undefined

  return (
    <>
      <div className="space-y-2 fade-in">
        <SectionTitle>
          <FileText className="h-3 w-3 inline mr-1" />
          File Details
        </SectionTitle>
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-xs">
            <span className="opacity-50">Path:</span>
            <span className="font-mono opacity-80 truncate">{node.file ?? node.label}</span>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="opacity-50">Domain:</span>
            <Badge
              variant="outline"
              className="text-[10px] h-5 border-0"
              style={{
                backgroundColor: node.domain === 'frontend' ? 'rgba(183,148,244,0.06)' : 'rgba(99,179,237,0.06)',
                color: node.domain === 'frontend' ? '#b794f4' : '#63b3ed',
              }}
            >
              {node.domain}
            </Badge>
          </div>
        </div>
      </div>
      <div className="divider-glow" />
      <div className="grid grid-cols-2 gap-3 fade-in">
        <div className="space-y-1 text-center">
          <span className="opacity-50 text-[10px]">Symbols</span>
          <div className="text-sm font-mono font-semibold">{symbolsCount ?? '—'}</div>
        </div>
        <div className="space-y-1 text-center">
          <span className="opacity-50 text-[10px]">Imports</span>
          <div className="text-sm font-mono font-semibold">{importsCount ?? '—'}</div>
        </div>
      </div>
      {owner && (
        <>
          <div className="divider-glow" />
          <div className="space-y-1 fade-in">
            <SectionTitle>Owner</SectionTitle>
            <div className="flex items-center gap-2 text-xs">
              <div
                className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold"
                style={{ backgroundColor: dark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)' }}
              >
                {owner.charAt(0).toUpperCase()}
              </div>
              <span className="opacity-80">{owner}</span>
            </div>
          </div>
        </>
      )}
      {detail.definedIn && detail.definedIn.length > 0 && (
        <>
          <div className="divider-glow" />
          <div className="space-y-1 fade-in">
            <SectionTitle>Definitions</SectionTitle>
            <RefList items={detail.definedIn!.map(d => ({ file: d.file, line: d.line, source: 'symbol' }))} dark={dark} />
          </div>
        </>
      )}
    </>
  )
}

function RouteSection({ detail, node, dark }: { detail: NodeDetail; node: GraphNode; dark: boolean }) {
  const data = node.data as Record<string, unknown>
  const method = data?.method as string | undefined
  const path = data?.path as string | undefined
  const handler = data?.handler as string | undefined
  const middleware = data?.middleware as string[] | undefined

  const methodColor: Record<string, string> = {
    GET: 'border-emerald-500/40 text-emerald-400 bg-emerald-500/5',
    POST: 'border-blue-400/40 text-blue-400 bg-blue-500/5',
    PUT: 'border-amber-500/40 text-amber-400 bg-amber-500/5',
    PATCH: 'border-amber-400/40 text-amber-400 bg-amber-500/5',
    DELETE: 'border-red-400/40 text-red-400 bg-red-500/5',
  }

  return (
    <>
      <div className="space-y-2 fade-in">
        <SectionTitle>
          <Route className="h-3 w-3 inline mr-1" />
          Route Details
        </SectionTitle>
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-xs">
            <span className="opacity-50">Method:</span>
            <Badge variant="outline" className={`text-[10px] h-5 font-mono font-bold ${methodColor[method ?? ''] ?? 'border-slate-400/40 text-slate-400 bg-slate-500/5'}`}>
              {(method ?? 'GET').toUpperCase()}
            </Badge>
          </div>
          {path && (
            <div className="flex items-center gap-2 text-xs">
              <span className="opacity-50">Path:</span>
              <span className="font-mono opacity-80">{path}</span>
            </div>
          )}
          {handler && (
            <div className="flex items-center gap-2 text-xs">
              <span className="opacity-50">Handler:</span>
              <Badge variant="secondary" className="text-[10px] h-5 bg-purple-500/5 text-purple-300 border-purple-500/10">
                {handler}
              </Badge>
            </div>
          )}
        </div>
      </div>
      {middleware && middleware.length > 0 && (
        <>
          <div className="divider-glow" />
          <div className="space-y-1.5 fade-in">
            <SectionTitle>Middleware Chain</SectionTitle>
            <ul className="space-y-0.5">
              {middleware.map((mw, i) => (
                <li key={`mw-${i}`} className="flex items-center gap-1.5 text-xs py-0.5">
                  <span className="opacity-30 text-[10px] font-mono w-4 text-right">{i + 1}.</span>
                  <ChevronRight className="h-3 w-3 opacity-30" />
                  <span className="opacity-80">{mw}</span>
                </li>
              ))}
            </ul>
          </div>
        </>
      )}
      <div className="divider-glow" />
      <div className="space-y-1.5 fade-in">
        <SectionTitle>API Endpoint</SectionTitle>
        <div
          className="rounded-lg px-3 py-2 text-xs font-mono"
          style={{ backgroundColor: dark ? 'rgba(0,0,0,0.25)' : 'rgba(0,0,0,0.03)' }}
        >
          <span className="opacity-50">{(method ?? 'GET').toUpperCase()}</span>{' '}
          <span className="opacity-80">{path ?? node.label}</span>
        </div>
      </div>
    </>
  )
}

function VariableSection({ detail, node, dark }: { detail: NodeDetail; node: GraphNode; dark: boolean }) {
  const data = node.data as Record<string, unknown>
  const inferredType = data?.inferredType as string | undefined
  const scope = data?.scope as string | undefined
  const refsCount = data?.refsCount as number | undefined

  return (
    <>
      <div className="space-y-2 fade-in">
        <SectionTitle>
          <Braces className="h-3 w-3 inline mr-1" />
          Variable Details
        </SectionTitle>
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-xs">
            <span className="opacity-50">Name:</span>
            <span className="font-mono font-medium">{node.label}</span>
          </div>
          {inferredType && (
            <div className="flex items-center gap-2 text-xs">
              <span className="opacity-50">Type:</span>
              <Badge variant="outline" className="text-[10px] h-5 border-slate-400/30 text-slate-400 bg-slate-500/5 font-mono">
                {inferredType}
              </Badge>
            </div>
          )}
          {scope && (
            <div className="flex items-center gap-2 text-xs">
              <span className="opacity-50">Scope:</span>
              <Badge variant="secondary" className="text-[10px] h-5 bg-purple-500/5 text-purple-300 border-purple-500/10">
                {scope}
              </Badge>
            </div>
          )}
        </div>
      </div>
      {detail.definedIn && detail.definedIn.length > 0 && (
        <>
          <div className="divider-glow" />
          <div className="space-y-1 fade-in">
            <SectionTitle>Definition</SectionTitle>
            <RefList items={detail.definedIn!.map(d => ({ file: d.file, line: d.line, source: 'def' }))} dark={dark} />
          </div>
        </>
      )}
      <div className="divider-glow" />
      <div className="space-y-1 fade-in">
        <SectionTitle>References</SectionTitle>
        <div className="flex items-center gap-2 text-xs">
          <span className="opacity-50">Count:</span>
          <span className="font-mono font-semibold">{refsCount ?? (detail.references?.length ?? 0)}</span>
        </div>
        {detail.references && detail.references.length > 0 && (
          <RefList items={detail.references!.slice(0, 10).map(r => ({ file: r.file, line: r.line, source: r.source }))} dark={dark} />
        )}
      </div>
    </>
  )
}

function ImportSection({ detail, node, dark }: { detail: NodeDetail; node: GraphNode; dark: boolean }) {
  const data = node.data as Record<string, unknown>
  const sourcePath = data?.sourcePath as string | undefined
  const importedSymbols = data?.importedSymbols as string[] | undefined
  const importType = data?.importType as string | undefined
  const dependentFiles = data?.dependentFiles as string[] | undefined

  return (
    <>
      <div className="space-y-2 fade-in">
        <SectionTitle>
          <Import className="h-3 w-3 inline mr-1" />
          Import Details
        </SectionTitle>
        <div className="space-y-1.5">
          {sourcePath && (
            <div className="flex items-center gap-2 text-xs">
              <span className="opacity-50">Source:</span>
              <span className="font-mono opacity-80">{sourcePath}</span>
            </div>
          )}
          {importType && (
            <div className="flex items-center gap-2 text-xs">
              <span className="opacity-50">Type:</span>
              <Badge variant="outline" className={`text-[10px] h-5 ${
                importType === 'default'
                  ? 'border-blue-400/40 text-blue-400 bg-blue-500/5'
                  : importType === 'named'
                    ? 'border-emerald-500/40 text-emerald-400 bg-emerald-500/5'
                    : 'border-slate-400/40 text-slate-400 bg-slate-500/5'
              }`}>
                {importType}
              </Badge>
            </div>
          )}
        </div>
      </div>
      {importedSymbols && importedSymbols.length > 0 && (
        <>
          <div className="divider-glow" />
          <div className="space-y-1.5 fade-in">
            <SectionTitle>Imported Symbols</SectionTitle>
            <div className="flex flex-wrap gap-1">
              {importedSymbols.map(s => (
                <Badge key={s} variant="secondary" className="text-[10px] h-5 bg-purple-500/5 text-purple-300 border-purple-500/10">
                  {s}
                </Badge>
              ))}
            </div>
          </div>
        </>
      )}
      {dependentFiles && dependentFiles.length > 0 && (
        <>
          <div className="divider-glow" />
          <div className="space-y-1 fade-in">
            <SectionTitle>Dependent Files</SectionTitle>
            <ul className="space-y-0.5">
              {dependentFiles.map((f, i) => (
                <li key={`dep-${i}`} className="flex items-center gap-1.5 text-xs font-mono py-0.5">
                  <ChevronRight className="h-3 w-3 opacity-30" />
                  <span className="opacity-80">{f}</span>
                </li>
              ))}
            </ul>
          </div>
        </>
      )}
    </>
  )
}

function CssVarSection({ detail, node, dark }: { detail: NodeDetail; node: GraphNode; dark: boolean }) {
  const data = node.data as Record<string, unknown>
  const value = data?.value as string | undefined
  const refsCount = data?.refsCount as number | undefined
  const usageLocations = data?.usageLocations as Array<{ file: string; line: number }> | undefined

  return (
    <>
      <div className="space-y-2 fade-in">
        <SectionTitle>
          <Palette className="h-3 w-3 inline mr-1" />
          CSS Variable Details
        </SectionTitle>
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-xs">
            <span className="opacity-50">Name:</span>
            <span className="font-mono font-medium">{node.label.startsWith('--') ? node.label : `--${node.label}`}</span>
          </div>
          {value && (
            <div className="flex items-center gap-2 text-xs">
              <span className="opacity-50">Value:</span>
              <div
                className="rounded-md px-2 py-0.5 font-mono text-[11px]"
                style={{ backgroundColor: dark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.04)' }}
              >
                {value}
              </div>
            </div>
          )}
        </div>
      </div>
      {detail.definedIn && detail.definedIn.length > 0 && (
        <>
          <div className="divider-glow" />
          <div className="space-y-1 fade-in">
            <SectionTitle>Defined In</SectionTitle>
            <RefList items={detail.definedIn!.map(d => ({ file: d.file, line: d.line, source: 'CSS' }))} dark={dark} />
          </div>
        </>
      )}
      <div className="divider-glow" />
      <div className="space-y-1 fade-in">
        <SectionTitle>References</SectionTitle>
        <div className="flex items-center gap-2 text-xs mb-1">
          <span className="opacity-50">Count:</span>
          <span className="font-mono font-semibold">{refsCount ?? (detail.references?.length ?? 0)}</span>
        </div>
      </div>
      {usageLocations && usageLocations.length > 0 && (
        <div className="space-y-1 fade-in">
          <SectionTitle>Usage Locations</SectionTitle>
          <ul className="space-y-0.5">
            {usageLocations.map((loc, i) => (
              <li key={`usage-${i}`} className="flex items-center gap-1.5 text-xs font-mono py-0.5">
                <ChevronRight className="h-3 w-3 opacity-30" />
                <span className="opacity-80">var({node.label.startsWith('--') ? node.label : `--${node.label}`})</span>
                <span className={`ml-auto shrink-0 font-mono text-[10px] ${dark ? 'text-slate-500' : 'text-slate-400'}`}>
                  {loc.file}:{loc.line}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
      {(!usageLocations || usageLocations.length === 0) && detail.references && detail.references.length > 0 && (
        <div className="space-y-1 fade-in">
          <SectionTitle>Usage Locations</SectionTitle>
          <RefList items={detail.references!.map(r => ({ file: r.file, line: r.line, source: `var()` }))} dark={dark} />
        </div>
      )}
    </>
  )
}

function KeyframeSection({ detail, node, dark }: { detail: NodeDetail; node: GraphNode; dark: boolean }) {
  const data = node.data as Record<string, unknown>
  const steps = data?.steps as string[] | undefined
  const referencedBy = data?.referencedBy as string[] | undefined
  const isOrphan = node.status === 'orphan'

  return (
    <>
      <div className="space-y-2 fade-in">
        <SectionTitle>
          <Film className="h-3 w-3 inline mr-1" />
          Keyframe Details
        </SectionTitle>
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-xs">
            <span className="opacity-50">Name:</span>
            <span className="font-mono font-medium">{node.label}</span>
          </div>
        </div>
      </div>
      {steps && steps.length > 0 && (
        <>
          <div className="divider-glow" />
          <div className="space-y-1 fade-in">
            <SectionTitle>Keyframe Steps</SectionTitle>
            <ul className="space-y-0.5">
              {steps.map((step, i) => (
                <li key={`step-${i}`} className="flex items-center gap-1.5 text-xs py-0.5">
                  <span className="opacity-30 text-[10px] font-mono w-4 text-right">{i + 1}.</span>
                  <ChevronRight className="h-3 w-3 opacity-30" />
                  <span className="opacity-80">{step}</span>
                </li>
              ))}
            </ul>
          </div>
        </>
      )}
      {referencedBy && referencedBy.length > 0 && (
        <>
          <div className="divider-glow" />
          <div className="space-y-1.5 fade-in">
            <SectionTitle>Referenced By</SectionTitle>
            <div className="flex flex-wrap gap-1">
              {referencedBy.map(ref => (
                <Badge key={ref} variant="secondary" className="text-[10px] h-5 bg-purple-500/5 text-purple-300 border-purple-500/10">
                  {ref}
                </Badge>
              ))}
            </div>
          </div>
        </>
      )}
      <div className="divider-glow" />
      <div className="space-y-1 fade-in">
        <SectionTitle>Orphan Status</SectionTitle>
        {isOrphan ? (
          <Badge variant="outline" className="text-[10px] h-5 border-amber-400/40 text-amber-400 bg-amber-500/5">
            ⚠ Unused keyframe — not referenced by any animation
          </Badge>
        ) : (
          <Badge variant="outline" className="text-[10px] h-5 border-emerald-500/40 text-emerald-400 bg-emerald-500/5">
            ✓ In use
          </Badge>
        )}
      </div>
    </>
  )
}

function TypeSpecificSection({ node, detail, dark }: { node: GraphNode; detail: NodeDetail; dark: boolean }) {
  switch (node.type) {
    case 'function':
      return <FunctionSection detail={detail} dark={dark} />
    case 'class':
      return <CssClassSection detail={detail} dark={dark} />
    case 'id':
      return <IdSection detail={detail} node={node} dark={dark} />
    case 'component':
      return <ComponentSection detail={detail} node={node} dark={dark} />
    case 'store':
      return <StoreSection detail={detail} node={node} dark={dark} />
    case 'package':
      return <PackageSection detail={detail} node={node} dark={dark} />
    case 'env_var':
      return <EnvVarSection detail={detail} node={node} dark={dark} />
    case 'secret':
      return <SecretSection detail={detail} node={node} dark={dark} />
    case 'vulnerability':
      return <VulnerabilitySection detail={detail} node={node} dark={dark} />
    case 'test':
      return <TestSection detail={detail} node={node} dark={dark} />
    case 'file':
      return <FileSection detail={detail} node={node} dark={dark} />
    case 'route':
      return <RouteSection detail={detail} node={node} dark={dark} />
    case 'variable':
      return <VariableSection detail={detail} node={node} dark={dark} />
    case 'import':
      return <ImportSection detail={detail} node={node} dark={dark} />
    case 'css_var':
      return <CssVarSection detail={detail} node={node} dark={dark} />
    case 'keyframe':
      return <KeyframeSection detail={detail} node={node} dark={dark} />
    default:
      return null
  }
}

// ─── Main Component ──────────────────────────────────────────

export function SlideInPanel({
  theme,
  node,
  detail,
  quickActions,
  onAction,
  onClose,
}: SlideInPanelProps) {
  const dark = theme === 'dark'
  const isOpen = node !== null

  const refCount = useMemo(() => {
    if (!detail) return 0
    return (
      (detail.callers?.length ?? 0) +
      (detail.callees?.length ?? 0) +
      (detail.references?.length ?? 0) +
      (detail.definedIn?.length ?? 0) +
      (detail.tests?.length ?? 0)
    )
  }, [detail])

  const borderColor = dark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.06)'
  const bgColor = dark ? 'rgba(8, 8, 16, 0.8)' : 'rgba(255, 255, 255, 0.88)'
  const textColor = dark ? '#e2e8f0' : '#1a202c'
  const mutedText = dark ? '#718096' : '#94a3b8'

  return (
    <div
      className="fixed top-0 right-0 h-full z-50 flex slide-in-panel"
      style={{
        transform: isOpen ? 'translateX(0)' : 'translateX(100%)',
        opacity: isOpen ? 1 : 0,
        width: 400,
        // Spring physics with slight overshoot
        transition: isOpen
          ? 'transform 400ms cubic-bezier(0.34, 1.56, 0.64, 1), opacity 350ms cubic-bezier(0.05, 0.7, 0.1, 1)'
          : 'transform 300ms cubic-bezier(0.16, 1, 0.3, 1), opacity 250ms cubic-bezier(0.16, 1, 0.3, 1)',
      }}
    >
      {/* Panel body with frosted glass + noise */}
      <div
        className="flex flex-col h-full w-full overflow-hidden relative"
        style={{
          backgroundColor: bgColor,
          color: textColor,
          borderLeft: `1px solid ${borderColor}`,
          backdropFilter: 'blur(24px) saturate(1.3)',
          WebkitBackdropFilter: 'blur(24px) saturate(1.3)',
          boxShadow: dark
            ? '-8px 0 32px rgba(0,0,0,0.4), inset 1px 0 0 rgba(255,255,255,0.03)'
            : '-8px 0 32px rgba(0,0,0,0.08), inset 1px 0 0 rgba(0,0,0,0.03)',
        }}
      >
        {/* Subtle noise texture overlay */}
        <div
          className="absolute inset-0 pointer-events-none opacity-[0.015]"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
            backgroundRepeat: 'repeat',
            backgroundSize: '128px 128px',
          }}
        />
        {/* Header with glow accent */}
        {node && (
          <div
            className="px-5 py-4 shrink-0 relative overflow-hidden"
            style={{ borderBottom: `1px solid ${borderColor}` }}
          >
            {/* Subtle top glow */}
            <div
              className="absolute top-0 left-0 right-0 h-1 opacity-60"
              style={{
                background: `linear-gradient(90deg, transparent, ${node.color}40, transparent)`,
              }}
            />
            <div className="flex items-center gap-3 relative">
              {/* Node icon with glow */}
              <div
                className="w-8 h-8 flex items-center justify-center rounded-lg"
                style={{
                  backgroundColor: `${node.color}10`,
                  boxShadow: `0 0 12px ${node.color}15`,
                }}
              >
                <span
                  className="text-base leading-none"
                  style={{ color: node.color, filter: `drop-shadow(0 0 4px ${node.color}40)` }}
                >
                  {shapeIcon(node.type)}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sm truncate">{node.label}</div>
                <div className="flex items-center gap-2 mt-0.5">
                  <span
                    className="text-[10px] font-medium uppercase tracking-wide px-2 py-0.5 rounded-full"
                    style={{
                      backgroundColor: `${node.color}10`,
                      color: node.color,
                    }}
                  >
                    {TYPE_LABELS[node.type]}
                  </span>
                  <span
                    className="inline-block h-1.5 w-1.5 rounded-full"
                    style={{ backgroundColor: STATUS_COLORS[node.status] }}
                  />
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 shrink-0 smooth-colors hover:bg-white/5 close-btn-rotate"
                onClick={onClose}
              >
                <X className="h-4 w-4" style={{ color: mutedText }} />
              </Button>
            </div>
          </div>
        )}

        {/* Scrollable content */}
        {node && (
          <ScrollArea className="flex-1 panel-scroll">
            <div className="p-5 space-y-4 stagger-children">
              {/* Location */}
              {node.file && (
                <div className="flex items-center gap-2 text-xs px-2 py-1.5 rounded-lg" style={{ backgroundColor: dark ? 'rgba(255,255,255,0.02)' : 'rgba(0,0,0,0.02)' }}>
                  <MapPin className="h-3.5 w-3.5 shrink-0" style={{ color: mutedText }} />
                  <span className="font-mono truncate opacity-60" style={{ color: mutedText }}>
                    {node.file}{node.line ? `:${node.line}` : ''}
                  </span>
                </div>
              )}

              {/* Badges */}
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant="outline" className="text-[10px] h-5 gap-1 border-0" style={{ backgroundColor: dark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.03)' }}>
                  <Tag className="h-2.5 w-2.5 opacity-50" />
                  {node.type}
                </Badge>
                <Badge
                  variant="outline"
                  className="text-[10px] h-5 border-0"
                  style={{
                    backgroundColor: node.domain === 'frontend' ? 'rgba(183,148,244,0.06)' : 'rgba(99,179,237,0.06)',
                    color: node.domain === 'frontend' ? '#b794f4' : '#63b3ed',
                  }}
                >
                  {node.domain}
                </Badge>
              </div>

              <div className="divider-glow" />

              {/* Status */}
              <div className="space-y-1.5">
                <SectionTitle>Status</SectionTitle>
                <div className="flex items-center gap-2 text-xs">
                  <span
                    className="inline-block h-2 w-2 rounded-full shrink-0"
                    style={{
                      backgroundColor: STATUS_COLORS[node.status],
                      boxShadow: `0 0 6px ${STATUS_COLORS[node.status]}40`,
                    }}
                  />
                  <span className="capitalize">{node.status.replace('_', ' ')}</span>
                  {refCount > 0 && (
                    <>
                      <span className="opacity-20">·</span>
                      <span style={{ color: mutedText }}>
                        {refCount} ref{refCount !== 1 ? 's' : ''}
                      </span>
                    </>
                  )}
                </div>
              </div>

              <div className="divider-glow" />

              {/* Type-specific section */}
              {detail && (
                <TypeSpecificSection node={node} detail={detail} dark={dark} />
              )}

              {/* Code snippet */}
              {detail?.code && (
                <>
                  <div className="divider-glow" />
                  <div className="space-y-2">
                    <SectionTitle>Code Snippet</SectionTitle>
                    <div
                      className="rounded-xl p-4 overflow-x-auto text-xs font-mono leading-relaxed border"
                      style={{
                        backgroundColor: dark ? 'rgba(0,0,0,0.25)' : 'rgba(0,0,0,0.03)',
                        borderColor: dark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.06)',
                        color: textColor,
                      }}
                    >
                      <pre className="whitespace-pre-wrap break-words">{detail.code}</pre>
                    </div>
                  </div>
                </>
              )}

              {/* Quick Actions */}
              {quickActions.length > 0 && (
                <>
                  <div className="divider-glow" />
                  <div className="space-y-2">
                    <SectionTitle>
                      <Zap className="h-3 w-3 inline mr-1" />
                      Quick Actions
                    </SectionTitle>
                    <div className="flex flex-wrap gap-2">
                      {quickActions.map((action, idx) => (
                        <Button
                          key={`${action.command}-${action.args.join('-')}-${idx}`}
                          size="sm"
                          variant={
                            action.variant === 'danger'
                              ? 'destructive'
                              : action.variant === 'warning'
                                ? 'outline'
                                : 'default'
                          }
                          className={`h-7 text-xs gap-1.5 audit-btn ${
                            action.variant === 'warning'
                              ? 'border-amber-500/30 text-amber-400 hover:bg-amber-500/5 hover:border-amber-500/50'
                              : action.variant === 'default'
                                ? 'bg-purple-600 hover:bg-purple-700 text-white border-0'
                                : ''
                          }`}
                          onClick={() => onAction(action)}
                        >
                          {action.label}
                        </Button>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          </ScrollArea>
        )}
      </div>
    </div>
  )
}
