---
name: codelens
description: >
  CodeLens v5 Quick Reference — concise trigger map, core commands, and decision rules
  for AI agents. For complete documentation, see SKILL.md.
---

# CodeLens v5 — Quick Reference

**MUST activate before writing/editing/deleting any class, id, or function.**

## State Prerequisites

1. No `.codelens/` → auto-run `init` → `scan` first
2. Registry stale (>24h) → auto-run `scan --incremental`
3. After code changes → always `scan --incremental` before re-query

## Trigger Map — User Intent → Tool

### Core (P0 — Always Trigger)

| User Intent | Tool | Command |
|-------------|------|---------|
| Create new class/id/function | `query` | `codelens query "name" ws` |
| Edit existing code | `query` + `context` | Query first, then context |
| Delete code | `impact` + `dead-code` | Impact check, then delete |
| "does this exist?" | `query` | `codelens query "name" ws` |
| "who calls this?" | `trace --direction up` | `codelens trace "name" ws` |
| Security audit | `secrets` → `dataflow` → `env-check` → `vuln-scan` | Full chain |
| Vulnerability scan | `vuln-scan` | `codelens vuln-scan ws` |

### Search & Understanding (P1)

| User Intent | Tool | Command |
|-------------|------|---------|
| Search pattern | `search` | `codelens search "pattern" ws` |
| Find symbol | `symbols` | `codelens symbols "name" ws` |
| Symbol detail | `context` | `codelens context "name" ws` |
| File structure | `outline` | `codelens outline ws --file path` |
| API routes | `api-map` | `codelens api-map ws` |
| Global state | `state-map` | `codelens state-map ws` |
| Performance issues | `perf-hint` | `codelens perf-hint ws` |

### Quality & Production (P1-P2)

| User Intent | Tool | Command |
|-------------|------|---------|
| "production ready?" | `smell` → `complexity` → `debug-leak` → `dead-code` → `a11y` → `secrets` | Quality gate |
| "what to refactor?" | `smell` | `codelens smell ws` |
| "too complex" | `complexity` | `codelens complexity ws` |
| "cleanup before deploy" | `debug-leak` | `codelens debug-leak ws` |
| "dead code?" | `dead-code` + `list --filter dead` | Full dead code |
| "accessible?" | `a11y` | `codelens a11y ws` |
| "CSS issues?" | `css-deep` | `codelens css-deep ws` |

### Refactoring (P1-P2)

| User Intent | Tool | Command |
|-------------|------|---------|
| "safe to rename?" | `refactor-safe` → `impact` → `test-map` | Full chain |
| "safe to delete?" | `impact` → `dead-code` | Impact then delete |
| "pure function?" | `side-effect` | `codelens side-effect ws` |
| "is it tested?" | `test-map` | `codelens test-map ws` |

## Query Decision Rules

| Query Result | Action |
|-------------|--------|
| `found: false` | SAFE — create new |
| `found: true` + `status: active` | EXTEND — don't overwrite |
| `found: true` + `status: dead` | ASK user — reuse or delete? |
| `found: true` + `status: duplicate_ref` | LIST all referrers first |
| `found: true` + `status: collision` | STOP — active bug, fix first |

## Negative Triggers — SKIP CodeLens

- Document generation (PDF, reports, docs)
- Image/media generation
- Web search queries
- Non-codebase knowledge questions
- Non-code file editing (config, markdown)

## Default Fallback Chains (Vague Requests)

| Pattern | Default Chain |
|---------|---------------|
| General "check/review" | `smell` → `dead-code` → `secrets` |
| "safe/secure?" | `secrets` → `dataflow` → `env-check` → `vuln-scan` |
| "good/clean/ready?" | `complexity` → `debug-leak` → `a11y` → `smell` |
| "slow/fast/optimize" | `perf-hint` → `complexity` → `circular` |
| "CSS/style/layout" | `css-deep` → `missing-refs` → `list --filter duplicate_define` |
| "deploy/ship/release" | `secrets` → `debug-leak` → `env-check` → `vuln-scan` → `dead-code` |

## Colloquial Triggers

| Phrase (EN/ID) | Tool Chain |
|-----------------|------------|
| "this is slow" / "kok lama ya" | `perf-hint` → `complexity` → `circular` |
| "something's weird" / "aneh nih" | `search` → `context` → `trace` → `missing-refs` |
| "help me check" / "bantu cek" | `smell` → `dead-code` → `secrets` |
| "clean up" / "bersihkan" | `debug-leak` → `dead-code` → `smell` |
| "is this safe?" / "aman ga" | `secrets` → `vuln-scan` → `debug-leak` → `env-check` |

## All 39 Commands Quick Reference

| # | Command | Priority | One-liner |
|---|---------|----------|-----------|
| 1 | `init` | P0 | Initialize workspace |
| 2 | `scan` | P0 | Scan & build registry |
| 3 | `query` | P0 | Check if name exists |
| 4 | `list` | P3 | List with filter |
| 5 | `detect` | P3 | Detect frameworks |
| 6 | `watch` | P3 | File watcher |
| 7 | `search` | P1 | Regex search |
| 8 | `symbols` | P1 | Registry symbol search |
| 9 | `trace` | P1 | Call chain trace |
| 10 | `impact` | P1 | Change impact analysis |
| 11 | `outline` | P2 | File structure outline |
| 12 | `missing-refs` | P2 | CSS/HTML mismatch |
| 13 | `diff` | P2 | Registry diff |
| 14 | `circular` | P2 | Circular dependency |
| 15 | `context` | P1 | Rich symbol context |
| 16 | `dependents` | P2 | Module import tracking |
| 17 | `validate` | P3 | Registry sanity check |
| 18 | `dataflow` | P0 | Source→sink analysis |
| 19 | `smell` | P0 | Code smell detection |
| 20 | `side-effect` | P1 | Pure vs impure |
| 21 | `refactor-safe` | P1 | Rename/move safety |
| 22 | `dead-code` | P1 | Enhanced dead code |
| 23 | `stack-trace` | P2 | Error propagation |
| 24 | `test-map` | P2 | Test coverage |
| 25 | `config-drift` | P2 | Dependency drift |
| 26 | `type-infer` | P3 | Type inference |
| 27 | `ownership` | P3 | Code ownership |
| 28 | `secrets` | P0 | Hardcoded secret scan |
| 29 | `entrypoints` | P0 | Entry point mapping |
| 30 | `api-map` | P1 | Route→handler mapping |
| 31 | `state-map` | P1 | State management |
| 32 | `env-check` | P1 | Environment audit |
| 33 | `debug-leak` | P2 | Debug code detection |
| 34 | `complexity` | P2 | Complexity scoring |
| 35 | `regex-audit` | P3 | Regex safety audit |
| 36 | `a11y` | P3 | Accessibility audit |
| 37 | `vuln-scan` | P0 | CVE vulnerability scan |
| 38 | `perf-hint` | P1 | Performance hints |
| 39 | `css-deep` | P2 | Deep CSS analysis |

## CLI Usage Pattern

```bash
CODELENS_DIR="{project_path}/skills/codelens"
CLI="python3 $CODELENS_DIR/scripts/codelens.py"

# Setup
$CLI init /workspace
$CLI scan /workspace

# Pre-write check (MOST IMPORTANT)
$CLI query "newName" /workspace

# Post-write update
$CLI scan /workspace --incremental

# Analysis
$CLI smell /workspace
$CLI secrets /workspace
$CLI vuln-scan /workspace
$CLI perf-hint /workspace
$CLI css-deep /workspace
```
